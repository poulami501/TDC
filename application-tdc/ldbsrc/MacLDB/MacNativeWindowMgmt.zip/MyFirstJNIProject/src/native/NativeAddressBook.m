#import <JavaNativeFoundation/JavaNativeFoundation.h> // helper framework for Cocoa and JNI development

/*
 * Class:     com_example_app_addressbook_NativeAddressBook
 * Method:    nativeUpLevelWindow
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_com_ctb_tdc_web_servlet_PersistenceServlet_nativeUpLevelWindow
(JNIEnv *env, jclass clazz, jstring javaWindowName)
{
    JNF_COCOA_ENTER(env);
    
    NSString *windowName = JNFJavaToNSString(env, javaWindowName);
    
    [NSApp activateIgnoringOtherApps:YES];
    
    NSArray * windows = [[NSApplication sharedApplication] orderedWindows];
    
    for(NSWindow *calcwindow in (NSArray *)windows) {
    
    //NSWindow *calcwindow = [[NSApplication sharedApplication]keyWindow];
    
        NSLog(@"     Native window has name: %@", calcwindow.title);
        
        if([calcwindow.title isEqualToString:windowName]) {
    
            [calcwindow setLevel:CGShieldingWindowLevel()+1];

            [calcwindow makeKeyAndOrderFront:nil];
    
            [NSMenu setMenuBarVisible:NO];
        } else {
            //[calcwindow setLevel:1];
        }
    }
    
    JNF_COCOA_EXIT(env);
}

