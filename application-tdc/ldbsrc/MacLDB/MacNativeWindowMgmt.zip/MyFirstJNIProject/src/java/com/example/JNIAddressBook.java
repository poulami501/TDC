package com.example;

import java.util.*;
import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import com.ti.eps.emu84.testAgency.EmulatorComponent;
import com.ti.eps.ngiexamcalc.gui.ti30.CalcPaneTI30;


public class JNIAddressBook {
	static {
		// ensure native JNI library is loaded
		System.loadLibrary("AddressBook");
	}
	
	private static native void nativeUpLevelWindow(final String windowName);
	
    private static void createAndShowTI84() {
        //Create and set up the window.
        JFrame frame = new JFrame("Graphing Calculator");
        
        frame.setAlwaysOnTop(true);
        frame.getRootPane().putClientProperty("Window.style", "small");
        frame.setResizable(false);
        frame.setIconImage(new ImageIcon("calc.png").getImage());
        
        EmulatorComponent emu = new EmulatorComponent(frame);
        
        emu.setFaceSize(EmulatorComponent.MEDIUM);
        emu.ResetEmulator();
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JLabel emptyLabel = new JLabel("");
        //emptyLabel.setPreferredSize(new Dimension(175, 100));
        frame.getContentPane().add(emptyLabel, BorderLayout.CENTER);
        
        //Display the window.
        frame.getContentPane().add(emu);
        frame.pack();
        
        frame.setVisible(true);
        
        while (true) {
            try {
                System.out.println("Calling native window method");
                nativeUpLevelWindow("Graphing Calculator");
                Thread.sleep(1000);
            } catch (InterruptedException ie) {
                // do nothing
            }
        }
    }
    
    private static void createAndShowTI30() {
        //Create and set up the window.
        JFrame frame = new JFrame("Graphing Calculator");
        
        frame.setAlwaysOnTop(true);
        frame.setResizable(false);
        frame.setIconImage(new ImageIcon("calc.png").getImage());
        frame.setSize(300, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        CalcPaneTI30 emu = new CalcPaneTI30(frame.getContentPane());
        frame.add(emu, BorderLayout.CENTER);
        
        frame.setVisible(true);
    }
    
    public static void main(String[] args) {
        //createAndShowTI84();
        createAndShowTI30();
    }
    
}
